package demo;

import java.net.MalformedURLException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

public class GUI extends Application {
	
	static boolean dialogPrompt = false;
	static boolean itemInfoShown = false;
	static ArrayList<Item> itemBank = new ArrayList<Item>();
	
	static TextField itemName;
	static TextField itemMinLvl;
	static TextField itemMaxLvl;
	static TextField itemGoldValue;
	static TextField itemWeight;
	static TextArea itemDescription;
	
	static TextField itemHealth;
	static TextField itemMana;
	static TextField itemAttack;
	static TextField itemSpecialAttack;
	static TextField itemDefense;
	static TextField itemSpecialDefense;
	static TextField itemAccuracy;
	static TextField itemEvasion;
	static TextField itemCritical;
	static TextField itemBlessing;
	
	static TextField itemType;
	static TextField itemArmorType;
	static TextField itemRanged;
	static TextField itemDualwield;
	static TextField itemAbilities;
	
	static TextField itemConsumable;
	static TextField itemXPRestored;
	static TextField itemHPRestored;
	static TextField itemManaRestored;
	static TextField itemHungerRestored;
	static TextField itemSARestored;
	 
	static Text playerTitleGui;
	static Text playerLevelGui;
	static Text playerXPGui;
	static Text playerHPGui;
	static Text playerMGui;
	static Text playerHGui;
	static Text playerSAGui;
	static Text playerGoldGui;
	static Text playerJewelsGui;
	static Text playerStrengthGui;
	static Text playerIntelligenceGui;
	static Text playerConstitutionGui;
	static Text playerDexterityGui;
	static Text playerIntegrityGui;
	static TextField playerNumberBox;
	static ImageView playerAttackButton;
	static Text playerAttackText;
	static ImageView playerSpecialAttackButton;
	static Text playerSpecialAttackText;
	
	static ArrayList<Player> playerList = new ArrayList<Player>();
	static ArrayList<SelectionBubble> playerSelectList = new ArrayList<SelectionBubble>(11);
	static ArrayList<InventorySpot> playerInventoryList = new ArrayList<InventorySpot>(28);	
	
	static int playerCount = 0;
	static int playerViewed = 0;	
	
	static Text enemyTitleGui;
	static Text enemyLevelGui;
	static Text enemyXPGui;
	static Text enemyHPGui;
	static Text enemyMGui;
	static Text enemyHGui;
	static Text enemySAGui;
	static Text enemyGoldGui;
	static Text enemyJewelsGui;
	static Text enemyStrengthGui;
	static Text enemyIntelligenceGui;
	static Text enemyConstitutionGui;
	static Text enemyDexterityGui;
	static Text enemyIntegrityGui;
	static TextField enemyNumberBox;
	static ImageView enemyAttackButton;
	static Text enemyAttackText;
	static ImageView enemySpecialAttackButton;
	static Text enemySpecialAttackText;
	
	static ArrayList<Player> enemyList = new ArrayList<Player>();
	static ArrayList<SelectionBubble> enemySelectList = new ArrayList<SelectionBubble>(11);
	static ArrayList<InventorySpot> enemyInventoryList = new ArrayList<InventorySpot>(28);
	
	static int enemyCount = 0;
	static int enemyViewed = 0;	
	
	static Group root;
	static Scene scene;
	static Pane bg; //Main
	static Pane ibg; //Item
	static Pane i1bg;
	static Pane i2bg;
	static Pane i3bg;
	static Pane i4bg;
	static Pane fbg; //Fighting
	static Pane pbg; //Player
	static Pane ebg; //Enemy


	
	@Override public void start(Stage primaryStage) throws MalformedURLException {
		
		CreateGUIObjects.setUpBasics();
		System.out.println("Done!");
		addPlayer(new Player("White Guy",true));
		addPlayer(new Player("RBG0 Guy",false));
		
		root.getChildren().addAll(bg,ibg,fbg,pbg,ebg); //Add pane to root
		primaryStage.setTitle("Quest Master"); //Title stage
		primaryStage.setScene(scene); //Set its scene
		primaryStage.show(); //Display
		
	}

	public static void addPlayer(Player newPly) {
		
		if (newPly.playerType)
			if (playerCount >= 13)
				return;
		else
			if (enemyCount >= 13)
				return;	
		
		ImageView img;
		if (newPly.playerType) {
			img = CreateGUIObjects.createImage(310, 100 + 25 * (playerCount), "Resources\\TabPlayerActive.png");
			GUI.bg.getChildren().add(img);
			bg.getChildren().add(newPly.tabTxt = CreateGUIObjects.createText(315, 119 + 25 * (playerCount), newPly.name, "Cooper Black", 10, Color.POWDERBLUE, TextAlignment.LEFT));
			playerList.add(newPly);
		} else {
			img = CreateGUIObjects.createImage(890, 100 + 25 * (enemyCount), "Resources\\TabEnemyActive.png");
			GUI.bg.getChildren().add(img);
			bg.getChildren().add(newPly.tabTxt = CreateGUIObjects.createText(900, 119 + 25 * (enemyCount), newPly.name, "Cooper Black", 10, Color.POWDERBLUE, TextAlignment.LEFT));
			enemyList.add(newPly);
		}
		newPly.tabImg = img;
		
		newPly.tabImg.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	if (!dialogPrompt)
		    		if (newPly.playerType)
		    			GUIManagement.setPlayerView(playerList.indexOf(newPly), true);
		    		else
		    			GUIManagement.setPlayerView(enemyList.indexOf(newPly), false);
		    	
		    }
		    
		});
		
		newPly.tabTxt.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	if (!dialogPrompt)
		    		if (newPly.playerType)
		    			GUIManagement.setPlayerView(playerList.indexOf(newPly), true);
		    		else
		    			GUIManagement.setPlayerView(enemyList.indexOf(newPly), false);
		    	
		    }
		    
		});
		
		if (newPly.playerType) {
			GUIManagement.setPlayerView(playerCount, true);
			playerViewed = playerCount;
			playerCount++;
		} else {
			GUIManagement.setPlayerView(enemyCount, false);
			enemyViewed = enemyCount;
			enemyCount++;
		}
		GUIManagement.updatePlayerGui(newPly);
	}
	
	public static void removePlayer(boolean isPlayer) {
		if (isPlayer) {
			bg.getChildren().remove(playerList.get(playerViewed).tabImg);
			bg.getChildren().remove(playerList.get(playerViewed).tabTxt);
			for (int i = playerViewed + 1; i < playerCount; i++) {
				playerList.set(i-1, playerList.get(i)); //Take each player ahead of the viewed one and place them back one space
				playerList.get(i-1).tabImg.setLayoutY(playerList.get(i-1).tabImg.getLayoutY()-25);
				playerList.get(i-1).tabTxt.setLayoutY(playerList.get(i-1).tabTxt.getLayoutY()-25);
			}
			playerList.remove(playerCount-1);
			if (playerViewed > 0)
				playerViewed--;
			playerCount--;
			GUIManagement.setPlayerView(playerViewed, true);
		} else {
			bg.getChildren().remove(enemyList.get(enemyViewed).tabImg);
			bg.getChildren().remove(enemyList.get(enemyViewed).tabTxt);
			for (int i = enemyViewed + 1; i < enemyCount; i++) {
				enemyList.set(i-1, enemyList.get(i)); //Take each enemy ahead of the viewed one and place them back one space
				enemyList.get(i-1).tabImg.setLayoutY(enemyList.get(i-1).tabImg.getLayoutY()-25);
				enemyList.get(i-1).tabTxt.setLayoutY(enemyList.get(i-1).tabTxt.getLayoutY()-25);
			}
			enemyList.remove(enemyCount-1);
			if (enemyViewed > 0)
				enemyViewed--;
			enemyCount--;
			GUIManagement.setPlayerView(enemyViewed, false);
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
}
