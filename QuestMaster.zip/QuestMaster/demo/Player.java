package demo;

import java.util.ArrayList;

import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class Player {

	//GUI
	ImageView tabImg = null;
	Text tabTxt = null;
	
	//Basic
	boolean playerType;
	String name;
	int level = 1;
	long hp = 0;
	long maxHp = 0;
	long exp = 0;
	long maxExp = 0;
	long mana = 0;
	long maxMana = 0;
	int hunger = 0;
	int maxHunger = 0;
	int superAbility = 0;
	int maxSuperAbility = 0;
	EntityEffect effect = null;
	
	//Currency
	long gold = 0;
	long goldBanked = 0;
	long maxGold = 0;
	long jewels = 0;
	long jewelsBanked = 0;
	long maxJewels = 0;
	
	//Status points
	int strength = 1; //2 attack, special attack, health, defense, special defense
	int intelligence = 1; // 2 special attack, 2 special defence, accuracy, blessing
	int constitution = 1; //2 defense, attack, critical, mana, health
	int dexterity = 1; //2 accuracy, 2 evasion, 2 critical
	int integrity = 1; //health, evasion, 2 mana, 2 blessing
	
	//Behind the scene status points
	int healthS = 3; //More HP
	int manaS = 3; //More Mana
	int attackS = 3; //damage dealt
	int specialAttackS = 3; //special damage dealt
	int defenseS = 3; //decreased damage taken
	int specialDefenseS = 3; //decreased special damage taken
	int accuracyS = 3; //chance to land a hit
	int evasionS = 3; //chance to avoid a hit
	int criticalS = 3; //chance to land a critical hit
	int blessingS = 3; //extra experience and higher loot drop rate
	
	//Items
	ArrayList<Item> inventory = new ArrayList<Item>();
	
	public Player(String newName, boolean player) {
		playerType = player;
		name = newName;
		updateBasic();
		refresh();
	}
	
	public static long levelToExp(int level) {
		return (long) Math.floor( SecretProperties.expQM * ( Math.pow(SecretProperties.expQA, Math.pow(level, SecretProperties.expQB)) + Math.pow(level, SecretProperties.expQC) ) );
	}
	
	public void refresh() {
		hp = maxHp;
		mana = maxMana;
		hunger = maxHunger;
		superAbility = maxSuperAbility;
		gold += SecretProperties.startingGold;
	}
	
	public void updateBasic() {
		maxHp = healthS * SecretProperties.healthToHP;
		maxExp = levelToExp(level);
		maxMana = manaS * SecretProperties.manaToM;
		maxHunger = SecretProperties.maxHunger;
		maxSuperAbility = SecretProperties.maxSuperAbility;
		maxGold = SecretProperties.maxGold;
		maxJewels = SecretProperties.maxJewels;
	}
	
	public void updateStatus() {
		healthS = strength + constitution + integrity;
		manaS = constitution + integrity * 2;
		attackS = strength * 2 + constitution;
		specialAttackS = strength + intelligence * 2;
		defenseS = strength + constitution * 2;
		specialDefenseS = intelligence * 2 + strength;
		accuracyS = intelligence + dexterity * 2;
		evasionS = dexterity * 2 + integrity;
		criticalS = constitution + dexterity * 2;
		blessingS = intelligence + integrity * 2;
	}
	
	public void setCurrency(int g, int gB, int j, int jB) {
		gold = g;
		goldBanked = gB;
		jewels = j;
		jewelsBanked = jB;
	}
	
	public void setStatus(int s, int i, int c, int d, int t) {
		strength = s;
		intelligence = i;
		constitution = c;
		dexterity = d;
		integrity = t;
	}
	
	public void addLvl(long newLvl) {
		if (level + newLvl > SecretProperties.maxLevel) {
			level = SecretProperties.maxLevel;
			maxExp = 0;
		} else if (level + newLvl < 1)
			level = 1;
		else
			level += newLvl;
		exp = 0;
		updateBasic();
	}
	
	public void addExp(long xp) {
		xp *= (1 + blessingS/450); //Add blessing
		while (exp + xp >= maxExp) { //If we're going to level up from getting this exp
			xp -= (maxExp - exp); //Set the xp we're adding to the ammount it was subtracting the value we used from it to level up.
			level++; //Level up
			maxExp = levelToExp(level); //Set the maxExp based on our level
			exp = 0; //Since we leveled, we need to set the exp to zero since we only took the necessary amount to get to 0.
		}
		if (exp + xp <= 0)
			exp = 0;
		else
			exp += xp; //If we're not leveling up anymore, we'll just add the xp that's left to our total 
	}
	
	public void addHp(long newHp) {
		if (hp + newHp > maxHp)
			hp = maxHp;
		else if (hp + newHp < 0)
			hp = 0;
		else
			hp += newHp;
	}
	
	public void addMana(long newMana) {
		if (mana + newMana > maxMana)
			mana = maxMana;
		else if (mana + newMana < 0)
			mana = 0;
		else
			mana += newMana;
	}
	
	public void addHunger(long newHunger) {
		if (hunger + newHunger > maxHunger)
			hunger = maxHunger;
		else if (hunger + newHunger < 0)
			hunger = 0;
		else
			hunger += newHunger;
	}
	
	public void addSuperAbility(long newSuperAbility) {
		if (superAbility + newSuperAbility > maxSuperAbility)
			superAbility = maxSuperAbility;
		else if (superAbility + newSuperAbility < 0)
			superAbility = 0;
		else
			superAbility += newSuperAbility;
	}
	
	public void addGold(long newGold) {
		if (gold + newGold > maxGold)
			gold = maxGold;
		else if (gold + newGold < 0)
			gold = 0;
		else
			gold += newGold;
	}
	
	public void addJewels(long newJewels) {
		if (jewels + newJewels > maxJewels)
			jewels = maxJewels;
		else if (jewels + newJewels < 0)
			jewels = 0;
		else
			jewels += newJewels;
	}
	
	public void addStrength(long newStrength) {
		if (strength + newStrength > SecretProperties.maxStat)
			strength = SecretProperties.maxStat;
		else if (strength + newStrength < 1)
			strength = 1;
		else
			strength += newStrength;
	}
	
	public void addIntelligence(long newIntelligence) {
		if (intelligence + newIntelligence > SecretProperties.maxStat)
			intelligence = SecretProperties.maxStat;
		else if (intelligence + newIntelligence < 1)
			intelligence = 1;
		else
			intelligence += newIntelligence;
	}
	
	public void addConstitution(long newConstitution) {
		if (constitution + newConstitution > SecretProperties.maxStat)
			constitution = SecretProperties.maxStat;
		else if (constitution + newConstitution < 1)
			constitution = 1;
		else
			constitution += newConstitution;
	}
	
	public void addDexterity(long newDexterity) {
		if (dexterity + newDexterity > SecretProperties.maxStat)
			dexterity = SecretProperties.maxStat;
		else if (dexterity + newDexterity < 1)
			dexterity = 1;
		else
			dexterity += newDexterity;
	}
	
	public void addIntegrity(long newIntegrity) {
		if (integrity + newIntegrity > SecretProperties.maxStat)
			integrity = SecretProperties.maxStat;
		else if (integrity + newIntegrity < 1)
			integrity = 1;
		else
			integrity += newIntegrity;
	}
	
}
