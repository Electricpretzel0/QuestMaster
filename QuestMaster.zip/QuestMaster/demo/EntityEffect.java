package demo;

public class EntityEffect {

	Player playerLink = null;
	String effectType = "";
	
	public EntityEffect(Player ply, String et) {
		playerLink = ply;
		effectType = et;
	}
 }
