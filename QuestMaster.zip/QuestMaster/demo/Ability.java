package demo;

public class Ability {

	String name;
	int manaCost = 0;
	
	//Multipliers
	static double attack = 1;
	static double specialAttack = 1;
	static double defense = 1;
	static double specialDefense = 1;
	static double evasion = 1;
	static double accuracy = 1;
	static double critical = 1;
	
	public Ability(String nm) {
		name = nm;
	}
}
