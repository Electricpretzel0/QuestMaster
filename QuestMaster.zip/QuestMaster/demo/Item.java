package demo;

import javafx.scene.image.ImageView;

public class Item {
	
	Player owner;
	ImageView guiImg;
	boolean selected;
	
	//Important features
	String name;
	int minLevel = 0;
	int maxLevel = SecretProperties.maxLevel;
	int manaCost = 0;
	int goldValue = 0;	
	double weight = 1; //pounds
	String description = "No futher information";
	
	//Item Specifics
	int itemType; //1 weapon, 2 armor, 3 jewelry, 4 other
	int armorType; //0 none, 1 helmet, 2 chestplate, 3 leggings, 4 boots, 5 gloves, 6 shield, 7 other
	boolean ranged;
	boolean dualwield;
	boolean stacks;
	String abilities; 
	
	//Consumable
	boolean consumable;
	int xpRestored;
	int hpRestored;
	int manaRestored;
	int hungerRestored;
	int saRestored;
	int quantity;
	
	
	//Status
	int health = 1;
	int mana = 1;
	int attack = 1; //damage dealt
	int specialAttack = 1; //special damage dealt
	int defense = 1; //decreased damage taken
	int specialDefense = 1; //decreased special damage taken
	int accuracy = 1; //chance to land a hit
	int evasion = 1; //chance to avoid a hit
	int critical = 1; //chance to land a critical hit
	int blessing = 1;
	
	
	
	public Item(String nm) {
		name = nm;
	}
	
}
