package demo;

import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class SelectionBubble {

	ImageView guiImg = null;
	Text guiText = null;
	boolean selected;
	long restriction;
	
	public SelectionBubble(ImageView iv, Text txt, long restrictNum,  boolean active) {
		guiImg = iv;
		guiText = txt;
		restriction = restrictNum;
		selected = active;
	}
	
}
