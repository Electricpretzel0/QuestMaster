package demo;


import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.paint.Color;

public class GUIManagement {
	
	static ImageView pexpBar = null;
	static ImageView phpBar = null;
	static ImageView pmanaBar = null;
	static ImageView phungerBar = null;
	static ImageView psaBar = null;
	static ImageView eexpBar = null;
	static ImageView ehpBar = null;
	static ImageView emanaBar = null;
	static ImageView ehungerBar = null;
	static ImageView esaBar = null;
	static Player fakeP = null;
	static Player fakeE = null;
	
	public static void setPlayerView(int p, boolean player) {
		if (player) {
			if (GUI.playerCount == 0)
				updatePlayerGui(fakeP = new Player("Nobody",true));
			else {
				try {
					for (Player ply: GUI.playerList) {
						ply.tabImg.setImage(new Image("Resources\\TabPlayer.png"));
						ply.tabTxt.setFill(Color.WHEAT);
					}
					Player viewp = GUI.playerList.get(p);
					viewp.tabImg.setImage(new Image("Resources\\TabPlayerActive.png"));
					viewp.tabTxt.setFill(Color.POWDERBLUE);
					updatePlayerGui(viewp);
					GUI.playerViewed = p;
					GUI.pbg.getChildren().remove(fakeP);
					fakeP = null;
				} catch (ArrayIndexOutOfBoundsException e) {
					System.out.println("That's not a player! arioob");
				} catch (IndexOutOfBoundsException e) {
					System.out.println("That's not a player! ioob");
				} catch (NullPointerException e) {
					System.out.println("That's not a player! np");
				}
			}
		} else {
			if (GUI.enemyCount == 0)
				updatePlayerGui(fakeE = new Player("Nobody",false));
			else {
				try {
					for (Player ply: GUI.enemyList) {
						ply.tabImg.setImage(new Image("Resources\\TabEnemy.png"));
						ply.tabTxt.setFill(Color.WHEAT);
					}
					Player viewp = GUI.enemyList.get(p);
					viewp.tabImg.setImage(new Image("Resources\\TabEnemyActive.png"));
					viewp.tabTxt.setFill(Color.POWDERBLUE);
					updatePlayerGui(viewp);
					GUI.enemyViewed = p;
					GUI.ebg.getChildren().remove(fakeE);
					fakeE = null;
				} catch (ArrayIndexOutOfBoundsException e) {
					System.out.println("That's not a enemy! ar");
				} catch (IndexOutOfBoundsException e) {
					System.out.println("That's not a enemy! i");
				} catch (NullPointerException e) {
					System.out.println("That's not a enemy! np");
				}
			}
		}
	}

	public static void updateInventory(Player ply) {
		
	}
	
	public static void updateBar(Player ply, int i) {
		int xL = 42;
		int yL = 77;
		double a=1;
		double b=1;
		ImageView bar = new ImageView();
		switch(i) {
			case(1):
				bar = CreateGUIObjects.createImage(xL, yL + (i-1)*20, "Resources\\ExperienceBarFill.png");
				a = ply.exp;
				b = ply.maxExp;
				break;
			case(2):
				bar = CreateGUIObjects.createImage(xL, yL + (i-1)*20, "Resources\\HealthBarFill.png");
				a = ply.hp;
				b = ply.maxHp;
				break;	
			case(3):
				bar = CreateGUIObjects.createImage(xL, yL + (i-1)*20, "Resources\\ManaBarFill.png");
				a = ply.mana;
				b = ply.maxMana;
				break;
			case(4):
				bar = CreateGUIObjects.createImage(xL, yL + (i-1)*20, "Resources\\HungerBarFill.png");
				a = ply.hunger;
				b = ply.maxHunger;
				break;
			case(5):
				bar = CreateGUIObjects.createImage(xL, yL + (i-1)*20, "Resources\\SuperAbilityBarFill.png");
				a = ply.superAbility;
				b = ply.maxSuperAbility;
				break;
		}
		int pixels = (int) Math.floor((a / b) * 166 + .5);

		if (pixels > 0 && pixels < 166) {
			
			PixelReader reader = bar.getImage().getPixelReader();
			WritableImage newImage = new WritableImage(reader, 0, 0, pixels, 12);
			ImageView temp = new ImageView(newImage);
			temp.setLayoutX(xL);
			temp.setLayoutY(yL + (i-1)*20);
			if (ply.playerType)
				GUI.pbg.getChildren().add(temp);
			else
				GUI.ebg.getChildren().add(temp);
			if (ply.playerType) {
				if (i==1) {
					if (pexpBar!=null)
						GUI.pbg.getChildren().remove(pexpBar);
					pexpBar = temp;	
				} else if (i==2) {
					if (phpBar!=null)
						GUI.pbg.getChildren().remove(phpBar);
					phpBar = temp;	
				} else if (i==3) {
					if (pmanaBar!=null)
						GUI.pbg.getChildren().remove(pmanaBar);
					pmanaBar = temp;	
				} else if (i==4) {
					if (phungerBar!=null)
						GUI.pbg.getChildren().remove(phungerBar);
					phungerBar = temp;
				} else if (i==5) {
					if (psaBar!=null)
						GUI.pbg.getChildren().remove(psaBar);
					psaBar = temp;	
				}
			} else {
				if (i==1) {
					if (eexpBar!=null)
						GUI.ebg.getChildren().remove(eexpBar);
					eexpBar = temp;	
				} else if (i==2) {
					if (ehpBar!=null)
						GUI.ebg.getChildren().remove(ehpBar);
					ehpBar = temp;	
				} else if (i==3) {
					if (emanaBar!=null)
						GUI.ebg.getChildren().remove(emanaBar);
					emanaBar = temp;	
				} else if (i==4) {
					if (ehungerBar!=null)
						GUI.ebg.getChildren().remove(ehungerBar);
					ehungerBar = temp;
				} else if (i==5) {
					if (esaBar!=null)
						GUI.ebg.getChildren().remove(esaBar);
					esaBar = temp;	
				}
			}	
		} else if (pixels <= 0) {
			if (ply.playerType) {
				if (i==1) {
					if (pexpBar!=null)
						GUI.pbg.getChildren().remove(pexpBar);
				} else if (i==2) {
					if (phpBar!=null)
						GUI.pbg.getChildren().remove(phpBar);
				} else if (i==3) {
					if (pmanaBar!=null)
						GUI.pbg.getChildren().remove(pmanaBar);
				} else if (i==4) {
					if (phungerBar!=null)
						GUI.pbg.getChildren().remove(phungerBar);
				} else if (i==5) {
					if (psaBar!=null)
						GUI.pbg.getChildren().remove(psaBar);
				}
			} else {
				if (i==1) {
					if (eexpBar!=null)
						GUI.ebg.getChildren().remove(eexpBar);
				} else if (i==2) {
					if (ehpBar!=null)
						GUI.ebg.getChildren().remove(ehpBar);
				} else if (i==3) {
					if (emanaBar!=null)
						GUI.ebg.getChildren().remove(emanaBar);
				} else if (i==4) {
					if (ehungerBar!=null)
						GUI.ebg.getChildren().remove(ehungerBar);
				} else if (i==5) {
					if (esaBar!=null)
						GUI.ebg.getChildren().remove(esaBar);
				}
			}
		} else {
			if (ply.playerType) {
				if (i==1) {
					if (pexpBar!=null)
						GUI.pbg.getChildren().remove(pexpBar);
					pexpBar = bar;	
				} else if (i==2) {
					if (phpBar!=null)
						GUI.pbg.getChildren().remove(phpBar);
					phpBar = bar;	
				} else if (i==3) {
					if (pmanaBar!=null)
						GUI.pbg.getChildren().remove(pmanaBar);
					pmanaBar = bar;	
				} else if (i==4) {
					if (phungerBar!=null)
						GUI.pbg.getChildren().remove(phungerBar);
					phungerBar = bar;
				} else if (i==5) {
					if (psaBar!=null)
						GUI.pbg.getChildren().remove(psaBar);
					psaBar = bar;	
				}
				GUI.pbg.getChildren().add(bar);
			} else {
				if (i==1) {
					if (eexpBar!=null)
						GUI.ebg.getChildren().remove(eexpBar);
					eexpBar = bar;	
				} else if (i==2) {
					if (ehpBar!=null)
						GUI.ebg.getChildren().remove(ehpBar);
					ehpBar = bar;	
				} else if (i==3) {
					if (emanaBar!=null)
						GUI.ebg.getChildren().remove(emanaBar);
					emanaBar = bar;	
				} else if (i==4) {
					if (ehungerBar!=null)
						GUI.ebg.getChildren().remove(ehungerBar);
					ehungerBar = bar;
				} else if (i==5) {
					if (esaBar!=null)
						GUI.ebg.getChildren().remove(esaBar);
					esaBar = bar;	
				}
				GUI.ebg.getChildren().add(bar);
			}
		}
		if (ply.playerType) {
			GUI.playerXPGui.toFront();
			GUI.playerHPGui.toFront();
			GUI.playerMGui.toFront();
			GUI.playerHGui.toFront();
			GUI.playerSAGui.toFront();
		} else {
			GUI.enemyXPGui.toFront();
			GUI.enemyHPGui.toFront();
			GUI.enemyMGui.toFront();
			GUI.enemyHGui.toFront();
			GUI.enemySAGui.toFront();
		}
	}
	
	public static void updatePlayerGui(Player plyV) {
		if (plyV.playerType) {
			GUI.playerTitleGui.setText(plyV.name + "'s Status");
			GUI.playerLevelGui.setText("Level: " + plyV.level);
			GUI.playerXPGui.setText("XP: " + plyV.exp + "/" + plyV.maxExp);
			GUI.playerHPGui.setText("HP: " + plyV.hp + "/" + plyV.maxHp);
			GUI.playerMGui.setText("M: " + plyV.mana + "/" + plyV.maxMana);
			GUI.playerHGui.setText("H: " + plyV.hunger + "/" + plyV.maxHunger);
			GUI.playerSAGui.setText("SA: " + plyV.superAbility + "/" + plyV.maxSuperAbility);
			GUI.playerGoldGui.setText("Gold: " + plyV.gold);
			GUI.playerJewelsGui.setText("Jewels: " + plyV.jewels);
			GUI.playerStrengthGui.setText("Strength: " + plyV.strength);
			GUI.playerIntelligenceGui.setText("Intelligence: " + plyV.intelligence);
			GUI.playerConstitutionGui.setText("Constitution: " + plyV.constitution);
			GUI.playerDexterityGui.setText("Dexterity: " + plyV.dexterity);
			GUI.playerIntegrityGui.setText("Integrity: " + plyV.integrity);
		} else {
			GUI.enemyTitleGui.setText(plyV.name + "'s Status");
			GUI.enemyLevelGui.setText("Level: " + plyV.level);
			GUI.enemyXPGui.setText("XP: " + plyV.exp + "/" + plyV.maxExp);
			GUI.enemyHPGui.setText("HP: " + plyV.hp + "/" + plyV.maxHp);
			GUI.enemyMGui.setText("M: " + plyV.mana + "/" + plyV.maxMana);
			GUI.enemyHGui.setText("H: " + plyV.hunger + "/" + plyV.maxHunger);
			GUI.enemySAGui.setText("SA: " + plyV.superAbility + "/" + plyV.maxSuperAbility);
			GUI.enemyGoldGui.setText("Gold: " + plyV.gold);
			GUI.enemyJewelsGui.setText("Jewels: " + plyV.jewels);
			GUI.enemyStrengthGui.setText("Strength: " + plyV.strength);
			GUI.enemyIntelligenceGui.setText("Intelligence: " + plyV.intelligence);
			GUI.enemyConstitutionGui.setText("Constitution: " + plyV.constitution);
			GUI.enemyDexterityGui.setText("Dexterity: " + plyV.dexterity);
			GUI.enemyIntegrityGui.setText("Integrity: " + plyV.integrity);
		}
		updateInventory(plyV);
		updateBar(plyV,1);
		updateBar(plyV,2);
		updateBar(plyV,3);
		updateBar(plyV,4);
		updateBar(plyV,5);
	}

	public static void changePlayerSelections(byte change, TextField box) {
		Player plyV = GUI.playerList.get(GUI.playerViewed);
		for (int i = 0; i < GUI.playerSelectList.size(); i++) {
    		SelectionBubble current = GUI.playerSelectList.get(i);
    		String labelText = current.guiText.getText();
    		if (current.selected) {
    			long nbVal = 0;
    			String specialText = labelText.substring(0,(labelText.indexOf(" ")));
    			boolean slashText = labelText.indexOf("/") != -1;
    			try {
    				nbVal = Long.parseLong(box.getText());
    				if (change!=0)
    					nbVal *= change;
    				else {
    					if (slashText)
    						nbVal -= Long.parseLong(labelText.substring( (labelText.indexOf(" ")+1), labelText.indexOf("/") ));
    					else
    						nbVal -= Long.parseLong(labelText.substring( (labelText.indexOf(" ")+1) ));
    				}
    					
    			} catch(NumberFormatException e) {
    				System.out.println("RIP");
    			}
    			switch(specialText) {
	    			case("Level:"):
	    				plyV.addLvl(nbVal);
	    			break;
	    			case("XP:"):
	    				plyV.addExp(nbVal);
	    			break;
	    			case("HP:"):
	    				plyV.addHp(nbVal);
	    			break;
	    			case("M:"):
	    				plyV.addMana(nbVal);
	    			break;
	    			case("H:"):
	    				plyV.addHunger(nbVal);
	    			break;
	    			case("SA:"):
	    				plyV.addSuperAbility(nbVal);
	    			break;
	    			case("Gold:"):
	    				plyV.addGold(nbVal);
	    			break;
	    			case("Jewels:"):
	    				plyV.addJewels(nbVal);
	    			break;
	    			case("Strength:"):
	    				plyV.addStrength(nbVal);
	    			break;
	    			case("Intelligence:"):
	    				plyV.addIntelligence(nbVal);
	    			break;
	    			case("Constitution:"):
	    				plyV.addConstitution(nbVal);
	    			break;
	    			case("Dexterity:"):
	    				plyV.addDexterity(nbVal);
	    			break;
	    			case("Integrity:"):
	    				plyV.addIntegrity(nbVal);
	    			break;
    			}
    		}
    	}
		plyV.updateStatus();
		plyV.updateBasic();
		updatePlayerGui(plyV);
	}
	
	public static void changeEnemySelections(byte change, TextField box) {
		Player plyV = GUI.enemyList.get(GUI.enemyViewed);
		for (int i = 0; i < GUI.enemySelectList.size(); i++) {
    		SelectionBubble current = GUI.enemySelectList.get(i);
    		String labelText = current.guiText.getText();
    		if (current.selected) {
    			long nbVal = 0;
    			String specialText = labelText.substring(0,(labelText.indexOf(" ")));
    			boolean slashText = labelText.indexOf("/") != -1;
    			try {
    				nbVal = Long.parseLong(box.getText());
    				if (change!=0)
    					nbVal *= change;
    				else {
    					if (slashText)
    						nbVal -= Long.parseLong(labelText.substring( (labelText.indexOf(" ")+1), labelText.indexOf("/") ));
    					else
    						nbVal -= Long.parseLong(labelText.substring( (labelText.indexOf(" ")+1) ));
    				}
    					
    			} catch(NumberFormatException e) {
    				System.out.println("RIP");
    			}
    			switch(specialText) {
	    			case("Level:"):
	    				plyV.addLvl(nbVal);
	    			break;
	    			case("HP:"):
	    				plyV.addHp(nbVal);
	    			break;
	    			case("M:"):
	    				plyV.addMana(nbVal);
	    			break;
	    			case("Strength:"):
	    				plyV.addStrength(nbVal);
	    			break;
	    			case("Intelligence:"):
	    				plyV.addIntelligence(nbVal);
	    			break;
	    			case("Constitution:"):
	    				plyV.addConstitution(nbVal);
	    			break;
	    			case("Dexterity:"):
	    				plyV.addDexterity(nbVal);
	    			break;
	    			case("Integrity:"):
	    				plyV.addIntegrity(nbVal);
	    			break;
    			}
    		}
    	}
		plyV.updateStatus();
		plyV.updateBasic();
		updatePlayerGui(plyV);
	}
	
	public static void changeSelections(byte change, TextField box, boolean isPlayer) {
		Player plyV; 
		if (isPlayer)
			plyV = GUI.playerList.get(GUI.playerViewed);
		else
			plyV = GUI.enemyList.get(GUI.enemyViewed);
		
		int ss = 0;
		if (isPlayer)
			ss = GUI.playerSelectList.size();
		else
			ss = GUI.enemySelectList.size();
		
		for (int i = 0; i < ss; i++) {
			SelectionBubble current;
			if (isPlayer)
				current = GUI.playerSelectList.get(i);
			else
				current = GUI.enemySelectList.get(i);
			
    		String labelText = current.guiText.getText();
    		if (current.selected) {
    			long nbVal = 0;
    			String specialText = labelText.substring(0,(labelText.indexOf(" ")));
    			boolean slashText = labelText.indexOf("/") != -1;
    			try {
    				nbVal = Long.parseLong(box.getText());
    				if (change!=0)
    					nbVal *= change;
    				else {
    					if (slashText)
    						nbVal -= Long.parseLong(labelText.substring( (labelText.indexOf(" ")+1), labelText.indexOf("/") ));
    					else
    						nbVal -= Long.parseLong(labelText.substring( (labelText.indexOf(" ")+1) ));
    				}
    					
    			} catch(NumberFormatException e) {
    				System.out.println("RIP");
    			}
    			switch(specialText) {
	    			case("Level:"):
	    				plyV.addLvl(nbVal);
	    			break;
	    			case("XP:"):
	    				plyV.addExp(nbVal);
	    			break;
	    			case("HP:"):
	    				plyV.addHp(nbVal);
	    			break;
	    			case("M:"):
	    				plyV.addMana(nbVal);
	    			break;
	    			case("H:"):
	    				plyV.addHunger(nbVal);
	    			break;
	    			case("SA:"):
	    				plyV.addSuperAbility(nbVal);
	    			break;
	    			case("Gold:"):
	    				plyV.addGold(nbVal);
	    			break;
	    			case("Jewels:"):
	    				plyV.addJewels(nbVal);
	    			break;
	    			case("Strength:"):
	    				plyV.addStrength(nbVal);
	    			break;
	    			case("Intelligence:"):
	    				plyV.addIntelligence(nbVal);
	    			break;
	    			case("Constitution:"):
	    				plyV.addConstitution(nbVal);
	    			break;
	    			case("Dexterity:"):
	    				plyV.addDexterity(nbVal);
	    			break;
	    			case("Integrity:"):
	    				plyV.addIntegrity(nbVal);
	    			break;
    			}
    		}
    	}
		plyV.updateStatus();
		plyV.updateBasic();
		updatePlayerGui(plyV);
	}
}
