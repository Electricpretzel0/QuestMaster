package demo;

import java.util.Random;

public class FightingSystem {
	
	public static int CollectStatusPoints(String stat, Player ply) {
		int total = 0;
		for (Item it: ply.inventory) {
			if (!it.selected) {
				switch(stat) {
					case("accuracy"):
						total += it.accuracy;
						break;
					case("attack"):
						total += it.attack;
						break;
					case("blessing"):
						total += it.blessing;
						break;
					case("critical"):
						total += it.critical;
						break;
					case("defense"):
						total += it.defense;
						break;
					case("evasion"):
						total += it.evasion;
						break;
					case("health"):
						total += it.health;
						break;
					case("mana"):
						total += it.mana;
						break;
					case("specialAttack"):
						total += it.specialAttack;
						break;
					case("specialDefense"):
						total += it.specialDefense;
						break;
				}
			}
		}
		return total;
	}
	public static double GenDouble() {
		Random num = new Random((long) Math.floor(SecretProperties.expQA * System.currentTimeMillis()));
		return num.doubles().findAny().getAsDouble();
	}

	public static double CalculateAccuracy(double ac1, double ev2) {
		double calcAc = .75; //75% starting accuracy
		
		if (ac1 - ev2 != 0) {//If there is a difference in accuracy and evasion
			calcAc += (ac1 - ev2)/(Math.pow(ac1 + ev2,SecretProperties.bAccuracyE) + SecretProperties.bAccuracyA); //Main equation: (x - y) / ( (x + y)^c1 + c2)
		}
		
		if (calcAc > .95) 
			calcAc = .95;
		else if (calcAc < .05)
			calcAc = .05;
		
		return calcAc;
	}
	
	public static double CalculateCriticalAccuracy(double cr1, double bl2) {
		double calcCrit = .1; //10% starting critical chance

		if (cr1 - bl2 != 0) {//If there is a difference in critical and blessing
			calcCrit += (cr1 - bl2)/(Math.pow(cr1 + bl2,SecretProperties.bAccuracyE) + SecretProperties.bCriticalA); //Main equation: (x - y) / ( (x + y)^c1 + c2)
		}
		
		if (calcCrit > .35) 
			calcCrit = .35;
		else if (calcCrit < .02)
			calcCrit = .02;

		return calcCrit;
	}
	
	public static int CalculateDamage(double at1, double de2, double plvl) {
		double dmg = (int) (SecretProperties.bDamageC * ( Math.pow((at1 * SecretProperties.bDamageA ), SecretProperties.bDamageB)) + SecretProperties.bDamageD);
		if (at1 - de2 != 0) {//If there is a difference in attack and defense
			
		}
		dmg*=(Math.floor((.75 + GenDouble()/4)*10000000)/10000000);
		return (int) dmg;
	}
	public static void simulateAttack(boolean isPlayer, boolean isSpecial) {
		Player attacker;
		Player defender;
		
		if (isPlayer) {
			attacker = GUI.playerList.get(GUI.playerViewed);
			defender = GUI.enemyList.get(GUI.enemyViewed);
		} else {
			attacker = GUI.enemyList.get(GUI.enemyViewed);
			defender = GUI.playerList.get(GUI.playerViewed);
		}
		
		if (CalculateAccuracy(attacker.accuracyS,defender.evasionS)>GenDouble()) { //If player hit enemy
			int dmg;
			if (isSpecial)
				dmg = CalculateDamage(attacker.specialAttackS,defender.specialDefenseS,attacker.level);
			else
				dmg = CalculateDamage(attacker.attackS,defender.defenseS,attacker.level);
			
			double critAcc = CalculateCriticalAccuracy(attacker.criticalS,defender.blessingS);
			if (critAcc>GenDouble()) {
				if (critAcc>GenDouble()) {
					if (critAcc>GenDouble())
						dmg*=SecretProperties.criticalM3;
				} else
					dmg*=SecretProperties.criticalM2;
			} else
				dmg*=SecretProperties.criticalM1;
			System.out.println(attacker.name + " dealt " + dmg + " damage to " + defender.name);
		} else {
			System.out.println("It missed!");
		}
		
	}
	
	
	public static void main(String[] args) {
		System.out.println(100*CalculateAccuracy(3,5) + "%");
		System.out.println(100*CalculateAccuracy(30,50) + "%");
		System.out.println(100*CalculateAccuracy(300,500) + "%");
		System.out.println(100*CalculateAccuracy(8,5) + "%");
		System.out.println(100*CalculateAccuracy(80,50) + "%");
		System.out.println(100*CalculateAccuracy(800,500) + "%");
		System.out.println("Critcal Chances");
		System.out.println(100*CalculateCriticalAccuracy(6,5) + "%");
		System.out.println(100*CalculateCriticalAccuracy(60,50) + "%");
		System.out.println(100*CalculateCriticalAccuracy(600,500) + "%");
	}
}
