package demo;

import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class InventorySpot {

	Item item;
	ImageView guiImg;
	ImageView itemImg;
	Text amount;
	boolean selected;
	
	public InventorySpot(ImageView is, ImageView iv, Item newItem, Text quantity) {
		item = newItem;
		guiImg = is;
		itemImg = iv;
		selected = false;
		amount = quantity;
		guiImg.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	if (me.isSecondaryButtonDown()) return;
		    	if (!GUI.dialogPrompt) {
			    	if (!selected){
			    		
			    		guiImg.setImage(new Image("Resources\\InventorySpotOpenActive.png"));
			    		selected = true;
			    		
			    	} else {
			    		
			    		guiImg.setImage(new Image("Resources\\InventorySpotOpen.png"));
			    		selected = false;
			    		
			    	}
		    	}
		        
		    }
		    
		});	
	}
}
