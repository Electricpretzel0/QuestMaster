package demo;

import demo.TextFieldValidator.ValidationModus;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TextFormatter;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.util.converter.IntegerStringConverter;

public class CreateGUIObjects {

	final static TextFormatter<Integer> formatterInteger = new TextFormatter<>(new IntegerStringConverter());
	
	public static Button createButton(int posX, int posY, int sizeX, int sizeY, String text, String font, int fontSize) { //Method for creating buttons
		Button button = new Button(text);
		//button.setFont(Font.font(font, fontSize)); //Font
		button.setLayoutX(posX); //Position
		button.setLayoutY(posY);
		button.setPrefSize(sizeX, sizeY); //Size
		return button; //return
	}
	
	public static Pane createPane(int posX, int posY, int sizeX, int sizeY, String color) { //Method for creating panes
		Pane pane = new Pane();
		pane.setPrefSize(sizeX,sizeY); //Size
		pane.setTranslateX(posX); //Position
		pane.setTranslateY(posY);
		pane.setStyle("-fx-background-color: #" + color + ";"); //Color in HEX
		return pane;
	}
	
	public static ImageView createImage(int x, int y, String image) { //Method for creating image
		Image img = new Image(image);
		ImageView imgView = new ImageView();
        imgView.setImage(img);
        imgView.setLayoutX(x);
        imgView.setLayoutY(y);
        imgView.setPreserveRatio(true);
        imgView.setSmooth(true);
        imgView.setCache(true);
		return imgView;
	}
	
	public static Text createText(int posX, int posY, String txt, String font, int fontSize, Color color, TextAlignment ta) { //Method for creating texts
		Text text = new Text(posX, posY, txt); //Position
		//text.setStyle("-fx-alignment: " + ta.toString() + ";");
		text.setTextAlignment(ta);
		text.setFill(color);
		text.setFont(Font.font(font, FontWeight.BOLD, fontSize)); //Font
		return text;
	}
	
	public static TextField createTextField(int posX, int posY, int sizeX, int sizeY, String txt, String font, int fontSize, String color, String ta) {
		TextField tf = new TextField();
		tf.setFocusTraversable(false);
		tf.setBackground(null);
		tf.setPrefSize(sizeX, sizeY);
		tf.setText(txt);
		tf.setStyle("-fx-text-fill: " + color + ";"
				+ " -fx-font-size: " + fontSize + ";"
				+ " -fx-font-family: '" + font + "';"
				+ " -fx-text-alignment: " + ta + ";");
		tf.setLayoutX(posX);
		tf.setLayoutY(posY);
		return tf;
	}
	public static TextArea createTextArea(int posX, int posY, int sizeX, int sizeY, String txt, String font, int fontSize, String color, String ta2, int rows) {
		TextArea ta = new TextArea();
		ta.setFocusTraversable(false);
		ta.setPrefSize(sizeX, sizeY);
		ta.setText(txt);
		ta.setWrapText(true);
		ta.setPrefRowCount(rows);
		ta.getStylesheets().add("Resources/QuestStyle.css");
		ta.setStyle("-fx-text-fill: " + color + ";"
				+ " -fx-font-size: " + fontSize + ";"
				+ " -fx-font-family: '" + font + "';"
				+ " -fx-text-alignment: " + ta2 + ";");	
		ta.setLayoutX(posX);
		ta.setLayoutY(posY);
		return ta;
	}
	
	public static TextField createTextField(int posX, int posY, int sizeX, int sizeY, String txt, String font, int fontSize, String color, String ta, int cc) {
		TextField tf = new TextField();
		tf.setFocusTraversable(false);
		tf.setBackground(null);
		tf.setPrefSize(sizeX, sizeY);
		tf.setText(txt);
		tf.setStyle("-fx-text-fill: " + color + ";"
				+ " -fx-font-size: " + fontSize + ";"
				+ " -fx-font-family: '" + font + "';"
				+ " -fx-text-alignment: " + ta + ";");
		tf.setLayoutX(posX);
		tf.setLayoutY(posY);
		tf.setTextFormatter(new TextFieldValidator(ValidationModus.INTEGERS_ONLY, 0).getFormatter());
		tf.setOnKeyPressed(new EventHandler<KeyEvent>() {
			
		    public void handle(KeyEvent me) {
		    	if (me.getText().matches("[0-9]")) {
			    	if (tf.getText().length()>cc-1) {
			    		tf.setText(tf.getText().substring(0, cc-1));
			    		tf.positionCaret(tf.getText().length()+1);
			    	}
		    	}
		    }
		    
		});
		return tf;
	}
	
	
	public static void createConfirmationBox(Pane bg, int entity) { //1 player 2 enemy 3 item
		GUI.dialogPrompt = true;
		ImageView backWindow = createImage(500, 270, "Resources\\InventoryPlayer.png");
		ImageView yesB = createImage(520, 390, "Resources\\YesOrNoButton.png");
		ImageView noB = createImage(680, 390, "Resources\\YesOrNoButton.png");
		Text prompt = createText(530, 310, "There is no way to recover an", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT);
		Text prompt2 = createText(530, 330, "entity once it has been deleted.", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT);
		Text prompt3 = createText(520, 380, " Will you continue?", "Cooper Black", 24, Color.WHEAT, TextAlignment.LEFT);
		Text yesT = createText(538, 417, "YES", "Cooper Black", 20, Color.WHEAT, TextAlignment.LEFT);
		Text noT = createText(704, 417, "NO", "Cooper Black", 20, Color.WHEAT, TextAlignment.LEFT);
		GUI.bg.getChildren().addAll(backWindow,yesB,noB,prompt,prompt2,prompt3,yesT,noT);
		yesB.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	bg.getChildren().removeAll(backWindow,prompt,prompt2,prompt3,noB,noT,yesB,yesT);
		    	if (entity==1) 
		    		GUI.removePlayer(true);
		    	else if (entity==2) 
		    		GUI.removePlayer(false);
		    	GUI.dialogPrompt = false;
		    	
		    }
		    
		});
		
		yesT.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	bg.getChildren().removeAll(backWindow,prompt,prompt2,prompt3,noB,noT,yesB,yesT);
		    	if (entity==1) 
		    		GUI.removePlayer(true);
		    	else if (entity==2) 
		    		GUI.removePlayer(false);
		    	GUI.dialogPrompt = false;
		    	
		    }
		    
		});
		
		noB.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	bg.getChildren().removeAll(backWindow,prompt,prompt2,prompt3,noB,noT,yesB,yesT);
		    	GUI.dialogPrompt = false;
		    	
		    }
		    
		});
		
		noT.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	bg.getChildren().removeAll(backWindow,prompt,prompt2,prompt3,noB,noT,yesB,yesT);
		    	GUI.dialogPrompt = false;
		    	
		    }
		    
		});

	}
	
	public static void createNamingWindow(int entity) { //1 player, 2 enemy, 3 item
		Pane np = createPane(500,270,0,0,"000000");
		GUI.root.getChildren().add(np);
		np.toFront();
		
		GUI.dialogPrompt = true;
		ImageView backWindow = createImage(0, 0, "Resources\\InventoryPlayer.png");
		ImageView yesB = createImage(100, 120, "Resources\\YesOrNoButton.png");
		ImageView backB = createImage(40, 73, "Resources\\NameBox.png");
		ImageView closeB = createImage(247, 5, "Resources\\SubtractBubble.png");
		Text prompt = createText(25, 45, "Change entity name?", "Cooper Black", 22, Color.WHEAT, TextAlignment.LEFT);
		Text yesT = createText(123, 147, "OK", "Cooper Black", 20, Color.WHEAT, TextAlignment.LEFT);
		TextField numberBox = createTextField(47, 80, 185, 15, "Name", "Cooper Black", 14, "white", "CENTER");
		
		np.getChildren().addAll(backWindow,yesB,backB,closeB,prompt,yesT,numberBox);
		
		yesT.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	Player ply;
		    	np.getChildren().removeAll(backWindow,prompt,backB,yesB,yesT,numberBox);
		    	GUI.root.getChildren().remove(np);
		    	if (entity==1)
		    		ply = GUI.playerList.get(GUI.playerViewed);	
		    	else
		    		ply = GUI.enemyList.get(GUI.enemyViewed);
		    	ply.name = numberBox.getText();
		    	ply.tabTxt.setText(numberBox.getText());
		    	GUIManagement.updatePlayerGui(ply);	
		    	GUI.dialogPrompt = false;
		    	
		    }
		    
		});
		yesB.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	np.getChildren().removeAll(backWindow,prompt,backB,yesB,yesT,numberBox);
		    	GUI.root.getChildren().remove(np);
		    	if (entity==1) {
		    		Player ply = GUI.playerList.get(GUI.playerViewed);
		    		ply.name = numberBox.getText();
		    		ply.tabTxt.setText(numberBox.getText());
		    		GUIManagement.updatePlayerGui(ply);
		    	} else {
		    		Player ply = GUI.enemyList.get(GUI.enemyViewed);
		    		ply.name = numberBox.getText();
		    		ply.tabTxt.setText(numberBox.getText());
		    		GUIManagement.updatePlayerGui(ply);
		    	}
		    	GUI.dialogPrompt = false;
		    	
		    }
		    
		});
		closeB.setOnMousePressed(new EventHandler<MouseEvent>() {
			
			public void handle(MouseEvent me) {
		    	
				np.getChildren().removeAll(backWindow,prompt,backB,yesB,yesT,numberBox);
		    	GUI.root.getChildren().remove(np);
		    	Player ply = GUI.playerList.get(GUI.playerViewed);
		    	GUIManagement.updatePlayerGui(ply);
		    	GUI.dialogPrompt = false;
		    	
		    }
		    
		});
	}
	
	
	/* QQQ   QQQQ  QQQQQ     Q   Q  QQQQ
	 *Q   Q  Q       Q       Q   Q  Q   Q
	 * QQ    QQQ     Q       Q   Q  QQQQ
	 *  QQ   Q       Q       Q   Q  Q
	 *Q   Q  Q       Q       Q   Q  Q
	 * QQQ   QQQQQ   Q        QQQ   Q
	 */
	
	public static void setUpBasics() {
		createStageGUI();
		createPlayerEnemyFrame();
		createFightingFrame();
		createItemFrame();
		/*
		 * MAIN FRAMES TO BUILD
		
		createRNGFrame();
		createSercretPropertiesFrame();
		createTutorialFrame();
		createLogTrackerFrame();
		*/
		
	}
	
	public static void createStageGUI() {
		GUI.root = new Group();
		GUI.scene = new Scene(GUI.root,1280, 720);
		GUI.scene.getStylesheets().add("Resources/QuestStyle.css");
		GUI.bg = createPane(0, 0, 1280, 720, "000000");
		GUI.bg.getChildren().addAll(
			createImage(0, 0, "Resources\\BackgroundLight720.png"),
			createImage(352, -10, "Resources\\Title.png")
		);
	}
	
	public static void createPlayerEnemyFrame() {
		GUI.pbg = createPane(0, 0, 0, 0, "000000");
		GUI.ebg = createPane(960, 0, 0, 0, "000000");
		int x = 0;
		for (x = 0; x < 2; x++) { //Player 0, then Enemy 1
			//
			//
			//Main GUI for both player and enemy
			//
			//
			
			{
				if (x == 0) {
					GUI.pbg.getChildren().addAll(
						createImage(0, 0, "Resources\\BackgroundPlayer.png"),
						createImage(35, 70, "Resources\\ExperiencePlayer.png"),
						createImage(35, 90, "Resources\\HealthPlayer.png"),
						createImage(35, 110, "Resources\\ManaPlayer.png"),
						createImage(35, 130, "Resources\\HungerPlayer.png"),
						createImage(35, 150, "Resources\\SuperAbilityPlayer.png"),
						createImage(210, 40, "Resources\\CharacterPlayer.png"),
						createImage(170, 205, "Resources\\NumberBox.png"),
						createImage(170, 270, "Resources\\NumberBox.png"),
						createImage(20, 320, "Resources\\InventoryPlayer.png"),
						createText(180, 202, "Effect", "Cooper Black", 14, Color.WHEAT, TextAlignment.CENTER),
						GUI.playerTitleGui = createText(25, 40, "Player's Status", "Cooper Black", 18, Color.WHEAT, TextAlignment.LEFT),
						GUI.playerLevelGui = createText(40, 70, "Level: 1", "Cooper Black", 18, Color.ANTIQUEWHITE, TextAlignment.LEFT),
						GUI.playerXPGui = createText(50, 87, "XP: 0/0", "Cooper Black", 12, Color.rgb(96, 112, 176), TextAlignment.CENTER),
						GUI.playerHPGui = createText(50, 107, "HP: 0/0", "Cooper Black", 12, Color.rgb(160, 64, 32), TextAlignment.LEFT),
						GUI.playerMGui = createText(50, 127, "M: 0/0", "Cooper Black", 12, Color.rgb(32, 160, 32), TextAlignment.CENTER),
						GUI.playerHGui = createText(50, 147, "H: 0/0", "Cooper Black", 12, Color.rgb(160, 160, 32), TextAlignment.CENTER),
						GUI.playerSAGui = createText(50, 167, "SA: 0/0", "Cooper Black", 12, Color.rgb(160, 32, 160), TextAlignment.CENTER),
						GUI.playerGoldGui = createText(40, 200, "Gold: 0", "Cooper Black", 14, Color.GOLD, TextAlignment.RIGHT),
						GUI.playerJewelsGui = createText(40, 220, "Jewels: 0", "Cooper Black", 14, Color.PLUM, TextAlignment.LEFT),	
						GUI.playerStrengthGui = createText(40, 240, "Strength: 0", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
						GUI.playerIntelligenceGui = createText(40, 260, "Intelligence: 0", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
						GUI.playerConstitutionGui = createText(40, 280, "Constitution: 0", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
						GUI.playerDexterityGui = createText(40, 300, "Dexterity: 0", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
						GUI.playerIntegrityGui = createText(40, 320, "Integrity: 0", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT)
					);
				} else {
					GUI.ebg.getChildren().addAll(
						createImage(0, 0, "Resources\\BackgroundPlayer.png"),
						createImage(35, 70, "Resources\\ExperiencePlayer.png"),
						createImage(35, 90, "Resources\\HealthPlayer.png"),
						createImage(35, 110, "Resources\\ManaPlayer.png"),
						createImage(35, 130, "Resources\\HungerPlayer.png"),
						createImage(35, 150, "Resources\\SuperAbilityPlayer.png"),
						createImage(210, 40, "Resources\\CharacterPlayer.png"),
						createImage(170, 205, "Resources\\NumberBox.png"),
						createImage(170, 270, "Resources\\NumberBox.png"),
						createImage(20, 320, "Resources\\InventoryPlayer.png"),
						createText(180, 202, "Effect", "Cooper Black", 14, Color.WHEAT, TextAlignment.CENTER),
						GUI.enemyTitleGui = createText(25, 40, "Enemy's Status", "Cooper Black", 18, Color.WHEAT, TextAlignment.LEFT),
						GUI.enemyLevelGui = createText(40, 70, "Level: 1", "Cooper Black", 18, Color.ANTIQUEWHITE, TextAlignment.LEFT),
						GUI.enemyXPGui = createText(50, 87, "XP: 0/0", "Cooper Black", 12, Color.rgb(96, 112, 176), TextAlignment.CENTER),
						GUI.enemyHPGui = createText(50, 107, "HP: 0/0", "Cooper Black", 12, Color.rgb(160, 64, 32), TextAlignment.LEFT),
						GUI.enemyMGui = createText(50, 127, "M: 0/0", "Cooper Black", 12, Color.rgb(32, 160, 32), TextAlignment.CENTER),
						GUI.enemyHGui = createText(50, 147, "H: 0/0", "Cooper Black", 12, Color.rgb(160, 160, 32), TextAlignment.CENTER),
						GUI.enemySAGui = createText(50, 167, "SA: 0/0", "Cooper Black", 12, Color.rgb(160, 32, 160), TextAlignment.CENTER),
						GUI.enemyGoldGui = createText(40, 200, "Gold: 0", "Cooper Black", 14, Color.GOLD, TextAlignment.RIGHT),
						GUI.enemyJewelsGui = createText(40, 220, "Jewels: 0", "Cooper Black", 14, Color.PLUM, TextAlignment.LEFT),	
						GUI.enemyStrengthGui = createText(40, 240, "Strength: 0", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
						GUI.enemyIntelligenceGui = createText(40, 260, "Intelligence: 0", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
						GUI.enemyConstitutionGui = createText(40, 280, "Constitution: 0", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
						GUI.enemyDexterityGui = createText(40, 300, "Dexterity: 0", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
						GUI.enemyIntegrityGui = createText(40, 320, "Integrity: 0", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT)
					);
				}
				
				GUI.bg.getChildren().add(createText(180, 202, "Effect", "Cooper Black", 14, Color.WHEAT, TextAlignment.CENTER));

			}
			System.out.println("Entity" + x + " has main components");
			
			//
			//
			//Name Changer
			//
			//
			
			{
				ImageView img;
				
				img = createImage(260, 20, "Resources\\MoreBubble.png");
				
				if (x == 0) {
					GUI.pbg.getChildren().add(img);
					img.setOnMousePressed(new EventHandler<MouseEvent>() {
						
					    public void handle(MouseEvent me) {
	
					    	if (!GUI.dialogPrompt) {
					    		img.setImage(new Image("Resources\\MoreBubbleActive.png"));
					    		createNamingWindow(1);
					    	}
					    	
					    }
					    
					});
				} else {
					GUI.ebg.getChildren().add(img);
					img.setOnMousePressed(new EventHandler<MouseEvent>() {
						
					    public void handle(MouseEvent me) {
	
					    	if (!GUI.dialogPrompt) {
					    		img.setImage(new Image("Resources\\MoreBubbleActive.png"));
					    		createNamingWindow(0);
					    	}
					    	
					    }
					    
					});
				}
				
				img.setOnMouseReleased(new EventHandler<MouseEvent>() {
					
				    public void handle(MouseEvent me) {
	
				    	img.setImage(new Image("Resources\\MoreBubble.png"));
				    	
				    }
				    
				});
			}
			
			//
			//
			//Inventory
			//
			//
			
			for (int y = 0; y < 4; y++) {//Gen inventory spots
				
				for (int x2 = 0; x2 < 7; x2++) {
					
					ImageView img;
					ImageView img2;
					img2 = createImage(47 + 35*x2, 349 + 35*y, "Resources\\Axe1.png"); 
					img = createImage(35 + 35*x2, 337 + 35*y, "Resources\\InventorySpotOpen.png"); 					
					Text quantity = createText(42 + 35*x2, 368 + 35*y, "1", "Cooper Black", 10, Color.WHEAT, TextAlignment.CENTER);
					InventorySpot spot = new InventorySpot(img,img2,null,quantity);
					if (x == 0) {
						GUI.pbg.getChildren().addAll(img2,img,quantity);
						GUI.playerInventoryList.add(spot);
					} else {
						GUI.ebg.getChildren().addAll(img2,img,quantity);
						GUI.enemyInventoryList.add(spot);
					}

				}
			}
			System.out.println("Entity" + x + " has inventory");
			
			//
			//
			//Effect Changer
			//
			//
			
			{
				
				ImageView img;
				
				img = createImage(225, 185, "Resources\\MoreBubble.png");
				if (x == 0)
					GUI.pbg.getChildren().add(img);
				else
					GUI.ebg.getChildren().add(img);
				img.setOnMousePressed(new EventHandler<MouseEvent>() {
					
				    public void handle(MouseEvent me) {
	
				    	if (!GUI.dialogPrompt) {
				    		img.setImage(new Image("Resources\\MoreBubbleActive.png"));
				    		createNamingWindow(1);
				    	}
				    	
				    }
				    
				});
				img.setOnMouseReleased(new EventHandler<MouseEvent>() {
					
				    public void handle(MouseEvent me) {
	
				    	img.setImage(new Image("Resources\\MoreBubble.png"));
				    	
				    }
				    
				});
			
			}
			System.out.println("Entity" + x + " has effects");
			
			//
			//
			//Selection Bubbles
			//
			//
			
			for (int y = 0; y < 13; y++) { //13 bubbles for both frames
				ImageView img;
				Text txt = null;
				long restrictNum = (long) ((Math.pow(2,63)) - 1); //MAX
				if (y<6)
					img = createImage(15, 50+20*y, "Resources\\SelectBubble.png");
				else
					img = createImage(15, 180+20*(y-6), "Resources\\SelectBubble.png");
				if (x == 0)
					GUI.pbg.getChildren().add(img);
				else
					GUI.ebg.getChildren().add(img);
				switch(y) {
					case(0):
						if (x == 0)
							txt = GUI.playerLevelGui;
						else
							txt = GUI.enemyLevelGui;
						restrictNum = SecretProperties.maxLevel;
						break;
					case(1):
						if (x == 0)
							txt = GUI.playerXPGui;
						else
							txt = GUI.enemyXPGui;
						restrictNum = 0;//GUI.playerList.get(GUI.playerViewed).maxExp;
						break;
					case(2):
						if (x == 0)
							txt = GUI.playerHPGui;
						else
							txt = GUI.enemyHPGui;
						restrictNum = 0;//GUI.playerList.get(GUI.playerViewed).maxHp;
						break;
					case(3):
						if (x == 0)
							txt = GUI.playerMGui;
						else
							txt = GUI.enemyMGui;
						restrictNum = 0;//GUI.playerList.get(GUI.playerViewed).maxMana;
						break;
					case(4):
						if (x == 0)
							txt = GUI.playerHGui;
						else
							txt = GUI.enemyHGui;
						restrictNum = 100;
						break;
					case(5):
						if (x == 0)
							txt = GUI.playerSAGui;
						else
							txt = GUI.enemySAGui;
						restrictNum = 100;
						break;
					case(6):
						if (x == 0)
							txt = GUI.playerGoldGui;
						else
							txt = GUI.enemyGoldGui;
						restrictNum = SecretProperties.maxGold;
						break;
					case(7):
						if (x == 0)
							txt = GUI.playerJewelsGui;
						else
							txt = GUI.enemyJewelsGui;
						restrictNum = SecretProperties.maxJewels;
						break;
					case(8):
						if (x == 0)
							txt = GUI.playerStrengthGui;
						else
							txt = GUI.enemyStrengthGui;
						restrictNum = SecretProperties.maxStat;
						break;
					case(9):
						if (x == 0)
							txt = GUI.playerIntelligenceGui;
						else
							txt = GUI.enemyIntelligenceGui;
						restrictNum = SecretProperties.maxStat;
						break;
					case(10):
						if (x == 0)
							txt = GUI.playerConstitutionGui;
						else
							txt = GUI.enemyConstitutionGui;
						restrictNum = SecretProperties.maxStat;
						break;
					case(11):
						if (x == 0)
							txt = GUI.playerDexterityGui;
						else
							txt = GUI.enemyDexterityGui;
						restrictNum = SecretProperties.maxStat;
						break;
					case(12):
						if (x == 0)
							txt = GUI.playerIntegrityGui;
						else
							txt = GUI.enemyIntegrityGui;
						restrictNum = SecretProperties.maxStat;
							break;
					}
					
					SelectionBubble bubble = new SelectionBubble(img,txt,restrictNum,false);
					
					if (x == 0)
						GUI.playerSelectList.add(bubble);
					else
						GUI.enemySelectList.add(bubble);
					
					img.setOnMousePressed(new EventHandler<MouseEvent>() {
						
					    public void handle(MouseEvent me) {
	
					    	if (!GUI.dialogPrompt) {
						    	if (!bubble.selected){
						    		
						    		img.setImage(new Image("Resources\\SelectBubbleActive.png"));
						    		bubble.selected = true;
						    		
						    	} else {
						    		
						    		img.setImage(new Image("Resources\\SelectBubble.png"));
						    		bubble.selected = false;
						    		
						    	}
					    	}
					    }
					    
					});
				
			}
			System.out.println("Entity" + x + " has selections");
			
			//
			//
			//Number Changer
			//
			//
			
			{

				TextField numberBox = new TextField();
				numberBox.setFocusTraversable(false);
				numberBox.setBackground(null);
				numberBox.setPrefColumnCount(6);
				numberBox.setStyle("-fx-text-fill: white; -fx-font-size: 14; -fx-font-family: 'Cooper Black'; -fx-alignment: CENTER;");
				numberBox.setLayoutX(167);
				numberBox.setLayoutY(275);
				
				if (x == 0) {
					GUI.playerNumberBox = numberBox;
					GUI.pbg.getChildren().add(numberBox);
				} else {
					GUI.enemyNumberBox = numberBox;
					GUI.ebg.getChildren().add(numberBox);
				}
				
				
				//Subtract	
				{	
					ImageView img;
					
					img = createImage(180 + x, 245, "Resources\\SubtractBubble.png"); //Attach image view to pane
					
					if (x == 0) {
						GUI.pbg.getChildren().add(img);
						img.setOnMousePressed(new EventHandler<MouseEvent>() {
							
						    public void handle(MouseEvent me) {
		
						    	if (!GUI.dialogPrompt) {
						    		img.setImage(new Image("Resources\\SubtractBubbleActive.png"));
						    		GUIManagement.changeSelections((byte) -1,numberBox,true);
						    	}
						    	
						    }
						    
						});
					} else {
						GUI.ebg.getChildren().add(img);
						img.setOnMousePressed(new EventHandler<MouseEvent>() {
							
						    public void handle(MouseEvent me) {
		
						    	if (!GUI.dialogPrompt) {
						    		img.setImage(new Image("Resources\\SubtractBubbleActive.png"));
						    		GUIManagement.changeSelections((byte) -1,numberBox,false);
						    	}
						    	
						    }
						    
						});
					}
					
					img.setOnMouseReleased(new EventHandler<MouseEvent>() {
						
					    public void handle(MouseEvent me) {
	
					    	img.setImage(new Image("Resources\\SubtractBubble.png"));
					    	
					    }
					    
					});
				}	
				//Add
				{
					ImageView img;
					
					img = createImage(229, 245, "Resources\\AddBubble.png"); //Attach image view to pane
					
					if (x == 0) {
						GUI.pbg.getChildren().add(img);
						img.setOnMousePressed(new EventHandler<MouseEvent>() {
							
						    public void handle(MouseEvent me) {
						    	
						    	if (!GUI.dialogPrompt) {
						    		img.setImage(new Image("Resources\\AddBubbleActive.png"));
						    		GUIManagement.changeSelections((byte) 1,numberBox,true);
						    	}
						    	
						    }
						    
						});
					} else {
						GUI.ebg.getChildren().add(img);
						img.setOnMousePressed(new EventHandler<MouseEvent>() {
							
						    public void handle(MouseEvent me) {
						    	
						    	if (!GUI.dialogPrompt) {
						    		img.setImage(new Image("Resources\\AddBubbleActive.png"));
						    		GUIManagement.changeSelections((byte) 1,numberBox,false);
						    	}
						    	
						    }
						    
						});
					}
					
					img.setOnMouseReleased(new EventHandler<MouseEvent>() {
						
					    public void handle(MouseEvent me) {
					    	
					    	img.setImage(new Image("Resources\\AddBubble.png"));
					    	
					    }
					    
					});
				}
				//Set
				{
					ImageView img;
					img = createImage(206, 245, "Resources\\SetBubble.png"); //Attach image view to pane
					
					if (x == 0) {
						GUI.pbg.getChildren().add(img);
						img.setOnMousePressed(new EventHandler<MouseEvent>() {
							
						    public void handle(MouseEvent me) {
						    	
						    	if (!GUI.dialogPrompt) {
						    		img.setImage(new Image("Resources\\SetBubbleActive.png"));
						    		GUIManagement.changeSelections((byte) 0,numberBox,true);
						    	}
						    }
						    
						});
					} else {
						GUI.ebg.getChildren().add(img);
						img.setOnMousePressed(new EventHandler<MouseEvent>() {
							
						    public void handle(MouseEvent me) {
						    	
						    	if (!GUI.dialogPrompt) {
						    		img.setImage(new Image("Resources\\SetBubbleActive.png"));
						    		GUIManagement.changeSelections((byte) 0,numberBox,false);
						    	}
						    }
						    
						});
					}
					
					img.setOnMouseReleased(new EventHandler<MouseEvent>() {
						
					    public void handle(MouseEvent me) {
					    	
					    	img.setImage(new Image("Resources\\SetBubble.png"));
					    	
					    }
					    
					});
				}	
			
			}
			System.out.println("Entity" + x + " has n changer");
			
			//
			//
			//PlayerButtons
			//
			//
			
			{ //Add Player
				
				ImageView img = createImage(310 - x*328, 75, "Resources\\AddBubble.png"); //Attach image view to pane
				boolean isPlayer;
				
				if (x == 0) {
					isPlayer = true;
					GUI.pbg.getChildren().add(img);
				} else {
					isPlayer = false;
					GUI.ebg.getChildren().add(img);
					
				}
				img.setOnMousePressed(new EventHandler<MouseEvent>() {
					
				    public void handle(MouseEvent me) {
				    	
				    	if (!GUI.dialogPrompt) {
					    	img.setImage(new Image("Resources\\AddBubbleActive.png"));
						    GUI.addPlayer(new Player("Untitled",isPlayer));
				    	}
				    }
				    
				});
				
				img.setOnMouseReleased(new EventHandler<MouseEvent>() {
					
				    public void handle(MouseEvent me) {
				    	
				    	img.setImage(new Image("Resources\\AddBubble.png"));
				    	
				    }
				    
				});
				
			} { //Remove Player
				
				ImageView img;
				
				img = createImage(335 - x*378, 75, "Resources\\SubtractBubble.png"); //Attach image view to pane
				if (x == 0) {
					GUI.pbg.getChildren().add(img);
					img.setOnMousePressed(new EventHandler<MouseEvent>() {
						
					    public void handle(MouseEvent me) {
					    	
					    	if (!GUI.dialogPrompt) {
						    	img.setImage(new Image("Resources\\SubtractBubbleActive.png"));
						    	if (GUI.playerCount>0)
						    		createConfirmationBox(GUI.bg, 1);
					    	}
					    }
					    
					});
					
				} else {
					GUI.ebg.getChildren().add(img);
					img.setOnMousePressed(new EventHandler<MouseEvent>() {
						
					    public void handle(MouseEvent me) {
					    	
					    	if (!GUI.dialogPrompt) {
						    	img.setImage(new Image("Resources\\SubtractBubbleActive.png"));
						    	if (GUI.enemyCount>0)
						    		createConfirmationBox(GUI.bg, 2);
					    	}
					    }
					    
					});
				}
			
				img.setOnMouseReleased(new EventHandler<MouseEvent>() {
					
				    public void handle(MouseEvent me) {
				    	
				    	img.setImage(new Image("Resources\\SubtractBubble.png"));
				    	
				    }
				    
				});
				
			} { //Swap Player
				
				ImageView img;
				String resource1, resource2;
				boolean isPlayer = (x==0);
				if (x == 0) {
					resource1 = "Resources\\ArrowBubbleRight.png";
					resource2 = "Resources\\ArrowBubbleRightActive.png";
					img = createImage(360 - x*428, 75, resource1);
					GUI.pbg.getChildren().add(img);
				} else {
					resource1 = "Resources\\ArrowBubbleLeft.png";
					resource2 = "Resources\\ArrowBubbleLeftActive.png";
					img = createImage(360 - x*428, 75, resource1);
					GUI.ebg.getChildren().add(img);
				}
				
				img.setOnMousePressed(new EventHandler<MouseEvent>() {

				    public void handle(MouseEvent me) {
				    	
				    	if (!GUI.dialogPrompt) {
				    		
				    		Player resource3;
				    		
					    	img.setImage(new Image(resource2));
					    	if (isPlayer) {
								if (GUI.playerCount>0)
									resource3 = GUI.playerList.get(GUI.playerViewed);
								else
									resource3 = new Player("Untitled",true);
							} else {
								if (GUI.enemyCount>0)
									resource3 = GUI.enemyList.get(GUI.enemyViewed);
								else
									resource3 = new Player("Untitled",false);
							}
					    	
					    	if (resource3.playerType) 
						    	if (GUI.playerCount>0)
						    		GUI.removePlayer(resource3.playerType);
						    	else
						    		return;
					    	else
					    		if (GUI.enemyCount>0)
						    		GUI.removePlayer(resource3.playerType);
						    	else
						    		return;
					    		
					    	resource3.playerType = !resource3.playerType;
						    GUI.addPlayer(resource3);
						    if (isPlayer)
						    	GUIManagement.setPlayerView(GUI.enemyCount-1, false);
						    else
						    	GUIManagement.setPlayerView(GUI.playerCount-1, true);
				    	}
				    }
				    
				});
				
				img.setOnMouseReleased(new EventHandler<MouseEvent>() {
					
				    public void handle(MouseEvent me) {
				    	
				    	img.setImage(new Image(resource1));
				    	
				    }
				    
				});
				
			}
			System.out.println("Entity" + x + " has add/drop e");
			
			
		} //end if x = 0,1
	}
	
	//
	//
	//Fighting
	//
	//
	
	public static void createFightingFrame() {
		GUI.fbg = createPane(440, 90, 0, 0, "000000");
		GUI.fbg.getChildren().addAll(
			createImage(0, 0, "Resources\\BackgroundFight.png"), //Fighting Frame
			GUI.playerAttackButton = createImage(15, 15, "Resources\\NumberBox.png"), //Attack
			GUI.playerAttackText = createText(40, 40, "Attack", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
			GUI.playerSpecialAttackButton = createImage(15, 65, "Resources\\NumberBox.png"), //Special Attack
			GUI.playerSpecialAttackText = createText(40, 90, "Special", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
			GUI.enemyAttackButton = createImage(285, 15, "Resources\\NumberBox.png"), //Attack
			GUI.enemyAttackText = createText(310, 40, "Attack", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT),
			GUI.enemySpecialAttackButton = createImage(285, 65, "Resources\\NumberBox.png"), //Special Attack
			GUI.enemySpecialAttackText = createText(310, 90, "Special", "Cooper Black", 14, Color.WHEAT, TextAlignment.LEFT)
		);	
		
		GUI.playerAttackButton.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.playerAttackButton.setImage(new Image("Resources\\NumberBoxActive.png"));
		    	GUI.playerAttackText.setFill(Color.POWDERBLUE);
		    	FightingSystem.simulateAttack(true, false);
		    	
		    }
		    
		});
		GUI.playerAttackButton.setOnMouseReleased(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.playerAttackButton.setImage(new Image("Resources\\NumberBox.png"));
		    	GUI.playerAttackText.setFill(Color.WHEAT);

		    }
		    
		});
		GUI.playerAttackText.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.playerAttackButton.setImage(new Image("Resources\\NumberBoxActive.png"));
		    	GUI.playerAttackText.setFill(Color.POWDERBLUE);
		    	FightingSystem.simulateAttack(true, false);
		    	
		    }
		    
		});
		GUI.playerAttackText.setOnMouseReleased(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.playerAttackButton.setImage(new Image("Resources\\NumberBox.png"));
		    	GUI.playerAttackText.setFill(Color.WHEAT);
		    	
		    }
		    
		});
		
		GUI.playerSpecialAttackButton.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.playerSpecialAttackButton.setImage(new Image("Resources\\NumberBoxActive.png"));
		    	GUI.playerSpecialAttackText.setFill(Color.POWDERBLUE);
		    	FightingSystem.simulateAttack(true, true);
		    	
		    }
		    
		});
		GUI.playerSpecialAttackButton.setOnMouseReleased(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.playerSpecialAttackButton.setImage(new Image("Resources\\NumberBox.png"));
		    	GUI.playerSpecialAttackText.setFill(Color.WHEAT);

		    }
		    
		});
		GUI.playerSpecialAttackText.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.playerSpecialAttackButton.setImage(new Image("Resources\\NumberBoxActive.png"));
		    	GUI.playerSpecialAttackText.setFill(Color.POWDERBLUE);
		    	FightingSystem.simulateAttack(true, true);
		    	
		    }
		    
		});
		GUI.playerSpecialAttackText.setOnMouseReleased(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.playerSpecialAttackButton.setImage(new Image("Resources\\NumberBox.png"));
		    	GUI.playerSpecialAttackText.setFill(Color.WHEAT);
		    	
		    }
		    
		});
		
		GUI.enemyAttackButton.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.enemyAttackButton.setImage(new Image("Resources\\NumberBoxActive.png"));
		    	GUI.enemyAttackText.setFill(Color.POWDERBLUE);
		    	FightingSystem.simulateAttack(false, false);
		    	
		    }
		    
		});
		GUI.enemyAttackButton.setOnMouseReleased(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.enemyAttackButton.setImage(new Image("Resources\\NumberBox.png"));
		    	GUI.enemyAttackText.setFill(Color.WHEAT);

		    }
		    
		});
		GUI.enemyAttackText.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.enemyAttackButton.setImage(new Image("Resources\\NumberBoxActive.png"));
		    	GUI.enemyAttackText.setFill(Color.POWDERBLUE);
		    	FightingSystem.simulateAttack(false, false);
		    	
		    }
		    
		});
		GUI.enemyAttackText.setOnMouseReleased(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.enemyAttackButton.setImage(new Image("Resources\\NumberBox.png"));
		    	GUI.enemyAttackText.setFill(Color.WHEAT);
		    	
		    }
		    
		});
		
		GUI.enemySpecialAttackButton.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.enemySpecialAttackButton.setImage(new Image("Resources\\NumberBoxActive.png"));
		    	GUI.enemySpecialAttackText.setFill(Color.POWDERBLUE);
		    	FightingSystem.simulateAttack(false, true);
		    	
		    }
		    
		});
		GUI.enemySpecialAttackButton.setOnMouseReleased(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.enemySpecialAttackButton.setImage(new Image("Resources\\NumberBox.png"));
		    	GUI.enemySpecialAttackText.setFill(Color.WHEAT);

		    }
		    
		});
		GUI.enemySpecialAttackText.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.enemySpecialAttackButton.setImage(new Image("Resources\\NumberBoxActive.png"));
		    	GUI.enemySpecialAttackText.setFill(Color.POWDERBLUE);
		    	FightingSystem.simulateAttack(false, true);
		    	
		    }
		    
		});
		GUI.enemySpecialAttackText.setOnMouseReleased(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	GUI.enemySpecialAttackButton.setImage(new Image("Resources\\NumberBox.png"));
		    	GUI.enemySpecialAttackText.setFill(Color.WHEAT);
		    	
		    }
		    
		});
	}
	
	//
	//
	//Item Bank
	//
	//
	
	public static void createItemFrame() {
		ImageView img, img2, itab1, itab2, itab3, itab4;
		GUI.ibg = createPane(440, 200, 0, 0, "000000");
		GUI.ibg.getChildren().addAll(
			createImage(0, 0, "Resources\\BackgroundItems.png"),
			createImage(235, 35, "Resources\\ItemList.png"),	
			createImage(10, 65, "Resources\\ItemProperties.png"),
			createImage(10, 10, "Resources\\Button1.png"),
			createText(27, 29, "Save", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(115, 30, "Item Manangement", "Cooper Black", 18, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 50, "Name: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			GUI.itemName = createTextField(57, 35, 190, 10, "", "Cooper Black", 10, "powderblue", "LEFT"),
			GUI.i1bg = createPane(10,30, 0, 0, "000000"),
			GUI.i2bg = createPane(10,30, 0, 0, "000000"),
			GUI.i3bg = createPane(10,30, 0, 0, "000000"),
			GUI.i4bg = createPane(10,30, 0, 0, "000000"),
			itab1 = createImage(30, 56, "Resources\\ItemTab.png"),
			itab2 = createImage(75, 56, "Resources\\ItemTab.png"),
			itab3 = createImage(120, 56, "Resources\\ItemTab.png"),
			itab4 = createImage(165, 56, "Resources\\ItemTab.png")
		);
		GUI.i1bg.getChildren().addAll(
			createText(20, 65, "Min Lvl: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 80, "Max Lvl: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 95, "Gold Value: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 110, "Weight: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 125, "Description: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			GUI.itemMinLvl = createTextField(67, 50, 40, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 4),
			GUI.itemMaxLvl = createTextField(68, 65, 40, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 4),
			GUI.itemGoldValue = createTextField(88, 80, 65, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 8),
			GUI.itemWeight = createTextField(66, 95, 65, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 3),
			GUI.itemDescription = createTextArea(10, 125, 200, 110, "", "Cooper Black", 12, "powderblue", "LEFT",8)
			
		);
		GUI.i2bg.getChildren().addAll(
			createText(20, 65, "Health: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 80, "Mana: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 95, "Attack: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 110, "Special Attack: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 125, "Defense: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 140, "Special Defense: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 155, "Accuracy: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 170, "Evasion: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 185, "Critical: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 200, "Blessing: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER)
		);
		GUI.i3bg.getChildren().addAll(
			createText(20, 65, "Type: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 80, "Armor Type: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 100, "Ranged: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 120, "Dualwield: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 140, "Abilities: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			img = createImage(180, 88, "Resources\\SpotUnchecked.png"),
			img2 = createImage(180, 108, "Resources\\SpotUnchecked.png")
		);
		GUI.i4bg.getChildren().addAll(
			createText(20, 65, "Consumable: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 80, "XP Restored: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 95, "HP Restored: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 110, "Mana Restored: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 125, "Hunger Restored: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER),
			createText(20, 140, "SA Restored: ", "Cooper Black", 12, Color.WHEAT, TextAlignment.CENTER)
		);
		GUI.i4bg.getChildren().addAll(
		
			GUI.itemHealth = createTextField(63, 95, 50, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 6),
			GUI.itemMana = createTextField(54, 110, 50, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 6),
			GUI.itemAttack = createTextField(63, 125, 50, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 6),
			GUI.itemSpecialAttack = createTextField(110, 140, 50, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 6),
			GUI.itemDefense = createTextField(69, 155, 50, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 6),
			GUI.itemSpecialDefense = createTextField(115, 170, 50, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 6),
			GUI.itemAccuracy = createTextField(77, 185, 50, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 6),
			GUI.itemEvasion = createTextField(69, 200, 50, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 6),
			GUI.itemCritical = createTextField(69, 215, 50, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 6),
			GUI.itemBlessing = createTextField(71, 230, 50, 10, "", "Cooper Black", 10, "powderblue", "LEFT", 6)
		); //Item Frame
		GUI.i1bg.setVisible(true);
		GUI.i2bg.setVisible(false);
		GUI.i3bg.setVisible(false);
		GUI.i4bg.setVisible(false);
		
		Image holder = img.getImage();
		img.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	if (img.getImage().equals(holder))
		    		img.setImage(new Image("Resources\\SpotChecked.png"));
		    	else
		    		img.setImage(holder);
		    }
		    
		});
		img2.setOnMousePressed(new EventHandler<MouseEvent>() {
			
		    public void handle(MouseEvent me) {
		    	
		    	if (img2.getImage().equals(holder))
		    		img2.setImage(new Image("Resources\\SpotChecked.png"));
		    	else
		    		img2.setImage(holder);
		    }
		    
		});
		itab1.setOnMousePressed(new EventHandler<MouseEvent>() {
			
			public void handle(MouseEvent me) {
				
				itab1.setImage(new Image("Resources\\ItemTabActive.png"));
		    	itab2.setImage(new Image("Resources\\ItemTab.png"));
		    	itab3.setImage(new Image("Resources\\ItemTab.png"));
		    	itab4.setImage(new Image("Resources\\ItemTab.png"));
		    		
				GUI.i1bg.setVisible(true);
				GUI.i2bg.setVisible(false);
				GUI.i3bg.setVisible(false);
				GUI.i4bg.setVisible(false);
		    	
		    }
		});
		itab2.setOnMousePressed(new EventHandler<MouseEvent>() {
			
			public void handle(MouseEvent me) {
				
				itab2.setImage(new Image("Resources\\ItemTabActive.png"));
		    	itab1.setImage(new Image("Resources\\ItemTab.png"));
		    	itab3.setImage(new Image("Resources\\ItemTab.png"));
		    	itab4.setImage(new Image("Resources\\ItemTab.png"));
		    		
				GUI.i2bg.setVisible(true);
				GUI.i1bg.setVisible(false);
				GUI.i3bg.setVisible(false);
				GUI.i4bg.setVisible(false);
		    	
		    }
		});
		itab3.setOnMousePressed(new EventHandler<MouseEvent>() {
			
			public void handle(MouseEvent me) {
				
				itab3.setImage(new Image("Resources\\ItemTabActive.png"));
		    	itab2.setImage(new Image("Resources\\ItemTab.png"));
		    	itab1.setImage(new Image("Resources\\ItemTab.png"));
		    	itab4.setImage(new Image("Resources\\ItemTab.png"));
		    		
				GUI.i3bg.setVisible(true);
				GUI.i2bg.setVisible(false);
				GUI.i1bg.setVisible(false);
				GUI.i4bg.setVisible(false);
		    	
		    }
		});
		itab4.setOnMousePressed(new EventHandler<MouseEvent>() {
			
			public void handle(MouseEvent me) {
				
				itab4.setImage(new Image("Resources\\ItemTabActive.png"));
		    	itab2.setImage(new Image("Resources\\ItemTab.png"));
		    	itab3.setImage(new Image("Resources\\ItemTab.png"));
		    	itab1.setImage(new Image("Resources\\ItemTab.png"));
		    		
				GUI.i4bg.setVisible(true);
				GUI.i2bg.setVisible(false);
				GUI.i3bg.setVisible(false);
				GUI.i1bg.setVisible(false);
		    	
		    }
		});
		
		ObservableList<String> names = FXCollections.observableArrayList();
		ListView<String> listView = new ListView<String>(names);
		listView.setLayoutX(250);
		listView.setLayoutY(50);
		listView.getStylesheets().add("Resources/QuestStyle.css");
		listView.setPrefSize(120, 210);
		
		listView.setBackground(null);
		GUI.ibg.getChildren().add(listView);
	}
}
