package demo;

public class SecretProperties {

	static int startingGold = 150;
	static int manaToM = 10;
	static int healthToHP = 50;
	static int maxStat = 300;
	static int maxLevel = 250;
	static int maxHunger = 100;
	static int maxSuperAbility = 100;
	static int maxGold = 999999999;
	static int maxJewels = 999999;
	
	static double criticalM1 = 1.75;
	static double criticalM2 = 3.5;
	static double criticalM3 = 5;
	
	static int bAccuracyA = 200;
	static int bCriticalA = 400;
	static double bAccuracyE = .85;
	
	static double bDamageA = 1.75;
	static double bDamageB = 1.3;
	static double bDamageC = .125;
	static double bDamageD = 10;
	static double bDamageE = 200;
	
	static double expQA = 2.06899245;
	static double expQB = 0.5;
	static double expQC = 1.5;
	static double expQM = 10.0;
	
}
