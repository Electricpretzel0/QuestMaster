package demo;

import javafx.event.EventHandler;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

public class Listener {
	
	class NumberedTextField4 implements EventHandler<KeyEvent> {
		
		TextField tf;
		
		public NumberedTextField4(TextField box) {
			tf = box;
		}
		public void handle(KeyEvent event) {
			if (event.getText().matches("[0-9]")) {
		    	if (tf.getText().length()>3) {
		    		tf.setText(tf.getText().substring(0, 3));
		    		tf.positionCaret(tf.getText().length()+1);
		    	}
	    	}
		}
	}
}
